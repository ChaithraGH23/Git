package corejava_Assignment1;

public class arraysearch
{
	public static void main(String args[])
	{
		int arr[]= {5,12,14,6,78,19,1,23,26,35,37,7,52,86,47};
		int search=47;
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]==search)
			{
			
				System.out.println("search is found :"+search);
				System.exit(0);
			}
		}
		
				System.out.print("Serch is not found");
			
	
        
		
		
		
	}

}
