package Stringbuffer;

public class reverse
{
	public static void main(String args[])
	{
		StringBuffer s1=new StringBuffer("this mentioned reverse object in which it is called");
		s1.reverse();
		System.out.print(s1);
	}

}
