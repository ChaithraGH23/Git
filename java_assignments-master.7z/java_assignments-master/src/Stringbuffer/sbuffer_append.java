package Stringbuffer;

public class sbuffer_append 
{
public static void main(String args[])
{
	StringBuffer s1= new StringBuffer("stringbuffer ");
	s1.append("is peer class of string");
	s1.append("that provides much of ");
	s1.append("functionality of strings ");
	System.out.print(s1);
}
}
