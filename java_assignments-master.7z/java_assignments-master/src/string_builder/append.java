package string_builder;

public class append 
{
  public static void main(String args[])
  {
	  StringBuilder s1=new StringBuilder("stringbuilder ");
	  
		s1.append("is peer class of string ");
		s1.append("that provides much of ");
		s1.append("functionality of strings ");
		System.out.print(s1);
  }
}
