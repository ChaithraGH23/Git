package string_builder;

public class reverse
{
	public static void main(String args[])
	{
		StringBuilder s1=new StringBuilder("this mentioned reverse object in which it is called");
		s1.reverse();
		System.out.print(s1);
	}

}
