package abstract_class;

class line  extends shape
{
	
	void draw()
	{
		System.out.println( "line");
	}
}
