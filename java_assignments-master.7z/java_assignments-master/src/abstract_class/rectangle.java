package abstract_class;

public class rectangle extends shape
{

	void draw()
	{
		System.out.println( "rectangle");
	}

	
}
