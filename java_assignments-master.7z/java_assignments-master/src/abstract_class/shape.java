package abstract_class;

abstract class shape
{
 abstract void draw();
 
}
