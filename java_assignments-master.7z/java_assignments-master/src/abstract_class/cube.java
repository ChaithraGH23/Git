package abstract_class;

public class cube  extends shape
{
	void draw()
	{
		System.out.println( "cube");
	}

}
