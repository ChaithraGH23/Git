package abstract_class;

public class solution
{
	public static void main(String args[])
	{
		shape s=new line();
		
		
	}

}
