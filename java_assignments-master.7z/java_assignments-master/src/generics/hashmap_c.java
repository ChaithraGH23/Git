package generics;

import java.util.HashMap;


public class hashmap_c 
{
	public static void main(String args[])
	{
		
			    // create a hashmap
			    HashMap<Integer, Double> num = new HashMap<>();

			    // add elements to hashmap
			    num.put(8, 8.0);
			    num.put( 1,8.0);
			    num.put(2,5.0);
			    num.put(4,5.0);
			    num.put(5,9.0);
			    num.put(0,7.0);
			    num.put(8,5.0);
			    num.put(5,5.0);
			    num.put(4,5.0);
			    num.put(9,5.0);
			    System.out.println("HashMap: " + num);
		
	}

}
