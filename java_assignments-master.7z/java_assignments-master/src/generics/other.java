package generics;

public class other
{
	int age;
	other(int age)
	{
		this.age=age;
	}

}
