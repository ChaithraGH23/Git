package abstract_functionality;

public  class mobile  extends laptop
{
   void start()
   {
	   System.out.println("mobile started"); 
   }
   void shutdown()
   {
	   System.out.println("System shutdown");
   }
}
//if we extend the abstract class we should implement abstract method 