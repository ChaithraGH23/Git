package abstract_functionality;

public class solu 
{
	public static void main(String args[])
	{
		laptop s;
		s=new mobile();
		s.shutdown();
		s.start();
        s.display();
	}

}
