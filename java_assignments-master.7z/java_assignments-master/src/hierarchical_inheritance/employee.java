package hierarchical_inheritance;

public class employee
{
	void  work() 
	{
		System.out.println("total salary of each Employee");
	}

}
