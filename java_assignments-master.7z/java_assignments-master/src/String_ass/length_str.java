package String_ass;

public class length_str 
{
 public static void main(String args[])
 {
	 String str="Hello World";
	 System.out.print(str.length());
	 
 }
}