package String_ass;

public class concate_str 
{
	public static void main(String args[])
	{
		String str="Hello ";
				String str1="How are you";
				System.out.print(str.concat(str1));
	}

}
